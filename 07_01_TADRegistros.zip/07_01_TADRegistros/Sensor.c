#include <stdio.h>
#include "Sensor.h"

Sensor crearSensor(){
	Sensor s;
	printf("Creando sensor");
	return s;
}

void mostrarSensor(Sensor s){
	printf("Sensor : \n");
}
	
int compararSensor(Sensor a, Sensor b){
	printf("Comparando sensores");
	
	return 0;
}


int estaEncendido(Sensor s){
	printf("analizando sensor");
	return 0 ;
}

void actualizaSensor(Sensor * s){
	printf("Actualizando Sensor : \n");
}

